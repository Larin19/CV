<?php
session_start();
$db = mysqli_connect('localhost', 'root', '', 'cv');
function x($data)
{
    global $db;
    $data = mysqli_real_escape_string($db, htmlspecialchars($data));
    return $data;
}
if (isset($_GET['d'])) {
    $id = x($_GET['d']);
    mysqli_query($db, "DELETE FROM `person` WHERE `id` = '$id'");
    header("Location:index.php");

    if ($_SESSION['admin']) {
        $adminid = $_SESSION['admin'];
    } elseif (isset($_SESSION['user'])) {
        $userid = $_SESSION['user'];
    }

    if ($_GET['logout']) {
        session_unset($_SESSION['admin']);
        session_destroy();
        unset($adminid);
        unset($userid);

        header("Location:index.php");
    }
}
?>
<?php ?>