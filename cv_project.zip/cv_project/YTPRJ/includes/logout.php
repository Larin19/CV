 

<?php


session_start();

if (isset($_SESSION['admin'])) {
    $adminid = $_SESSION['admin'];
} elseif (isset($_SESSION['user'])) {
    $userid = $_SESSION['user'];
}
